use gestiunea_vanzarilor;

SELECT * FROM produse 
WHERE denumire_prod LIKE 'C%';

SELECT * FROM produse 
WHERE denumire_prod LIKE '%i';

SELECT * FROM produse 
WHERE denumire_prod LIKE '__i';

SELECT * FROM produse 
WHERE denumire_prod LIKE '__i%';

SELECT * FROM produse 
WHERE denumire_prod LIKE '______';

SELECT nume, adresa FROM clienti
WHERE telefon IS NULL;

SELECT nume, adresa, telefon FROM clienti 
WHERE telefon IS NOT NULL;

SELECT * FROM produse 
ORDER BY denumire_prod ASC;

SELECT * FROM produse 
ORDER BY denumire_prod DESC;

SELECT denumire_prod FROM produse
ORDER BY denumire_prod ASC;

SELECT clienti.nume, facturi.* FROM facturi 
JOIN clienti ON clienti.cod_client=facturi.cod_client
ORDER BY clienti.nume DESC;

SELECT * FROM facturi
ORDER BY data_fact DESC;

SELECT clienti.nume, pret_fact+cota_tva AS Total FROM detalii_fact
JOIN facturi ON facturi.nr_fact=detalii_fact.nr_fact
JOIN clienti ON clienti.cod_client=facturi.cod_client
ORDER BY clienti.nume DESC;

SELECT clienti.nume, cantitatea FROM detalii_fact
JOIN facturi ON facturi.nr_fact=detalii_fact.nr_fact
JOIN clienti ON clienti.cod_client=facturi.cod_client
ORDER BY clienti.nume DESC;

SELECT facturi.data_fact,pret_fact+cota_tva AS Suma FROM detalii_fact
JOIN facturi ON facturi.nr_fact=detalii_fact.nr_fact
ORDER BY data_fact DESC;